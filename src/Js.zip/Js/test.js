// var x=2;

// y=x;
// console.log('value of y',y);
// console.log('value of x before',x);
// x=4;
// console.log('value of x after',x);
// console.log('value of y after',y);
//  var x=40;
// function test(){
//     var x=2;
    
// }
// test();
// console.log('value of x',x);

// let counter=0;
// counter++;
// console.log(counter);

// const myf=()=>{

// }

// var js = (function(x) {return x*x;}(10));
// console.log(js);


//javascript:alert('Hello, World!');

// var a=5 , b=1
// var obj = { a : 10,b:5 }
// // with keyword in JavaScript
// with(obj)
// {
//       console.log(b)
// }


// (function(){
//       setTimeout(()=> console.log(1),2000);
//       console.log(2);
//       setTimeout(()=> console.log(3),0);
//       console.log(4);
//      })();


   


   //  (function(a){
   //     return (function b(){
   //          console.log(a);
   //     })()
   //  })(2)


   //  console.log(typeof(null));

var answer="YES";
   switch (answer) {   
      case "YES":     
      console.log("You said YES!"); 
    
      case "NO":     
      console.log("You said no. :(");
      break;
      case "ELSE":     
      console.log("You said ELSE. :(");
   
   }