// function currying
// alert(2);
// function add(x) {
//   return function (y) {
//     return x + y;
//   };
// }
// const selfadd = add(3);
// console.log(selfadd);

// const newadd = selfadd(5);
// console.log(newadd);


// console.log(0.1+0.2===0.3);  // false 


x=5;
y=2;
x=x%y;
x=x**y;
console.log('value of x',x);