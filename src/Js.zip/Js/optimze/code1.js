// a function to add number without memorized way 

function addNumber(n){
    console.log(n+10);
    return n+10;
}
addNumber(20);
addNumber(20);
addNumber(20);


function addNumber2(n){

}