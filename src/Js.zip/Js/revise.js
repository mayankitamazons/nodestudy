console.log("revise of all java script logic");
