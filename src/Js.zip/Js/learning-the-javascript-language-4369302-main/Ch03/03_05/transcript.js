var myArray = [];
myArray;

var daysOfTheWeek = ["Sunday", "Monday", "Tuesday", "Wednesday"];
daysOfTheWeek;

var myList = [0, 1, 2, "string1", "string2", "string3", true, false];
myList;

var counties = ["Belknap", "Strafford", "Carroll", "Rockingham"];
counties;

var listOfStuff = [{ name: "value" }, [1, 2, 3], true, "nifty"];
listOfStuff;
listOfStuff.length;

// More info:
// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Grammar_and_types#array_literals
// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array
