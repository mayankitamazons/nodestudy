// This is a transcript of the lines of code from the lesson.
// You can copy and paste each line into a JavaScript console to execute it and see the result.

const dozen = 12, halfDozen = 6, bakersDozen = 13;

dozen = 13;

var cookieCount = 5;
let cookieCount = 5;

// More info:
// http://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Statements/let
// http://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Statements/const