/**
 * Classes
 */

let Cake = {};

Cake.prototype.bake = function(temp, minutes) {
  // Bake a cake at a particular temperature
  // for a number of minutes
}

class CakeClass {
  bake(temp, minutes) {

  }
}
